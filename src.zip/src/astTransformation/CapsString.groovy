class CapsString{
  @Delegate String body
  
}