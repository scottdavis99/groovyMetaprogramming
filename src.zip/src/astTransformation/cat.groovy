@Category(org.apache.commons.lang.StringUtils)
class TestString{
  String body
  String example(){
      return body.capitaliseAllWords()      
  }
}