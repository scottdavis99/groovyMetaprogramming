def message = """This 

is

my 

message"""

println message.class