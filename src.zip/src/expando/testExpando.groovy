def e = new Expando()
e.latitude = 70 
e.longitude = 30 
println e


e.areWeLost = {-> 
  return (e.longitude != 30) || (e.latitude != 70)
} 

e.areWeLost()
//===> false
e.latitude = 12 
e.areWeLost() 
//===> true

e.goNorth = { howMuch -> 
  e.latitude += howMuch
}
println e.latitude 
//===> 12
e.goNorth(20) 
//===> 32
