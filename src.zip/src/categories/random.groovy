use(RandomHelper){ 
  15.times{ println 10.rand() }
}

class RandomHelper{ 
  static int rand(Integer self){
    def r = new Random() 
    return r.nextInt(self.intValue())
  }
}  