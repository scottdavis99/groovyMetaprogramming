@Grab("commons-lang:commons-lang:2.4")
import org.apache.commons.lang.StringUtils

use(StringUtils){
  def sentence = "My name is Inigo Montoya. You killed my father. Prepare to die."
  println sentence
  
  //NOTE: the method signature change
  println sentence.abbreviate(15)
}