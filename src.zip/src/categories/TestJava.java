import org.apache.commons.lang.*;

public class TestJava{
  public static void main(String[] args){
    String sentence = "My name is Inigo Montoya. You killed my father. Prepare to die.";
    System.out.println(sentence);
    System.out.println(StringUtils.abbreviate(sentence, 15));    
  }
}