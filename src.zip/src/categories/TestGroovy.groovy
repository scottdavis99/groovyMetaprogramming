import org.apache.commons.lang.*

use(StringUtils, TestCategoryForString){
  def sentence = "My name is Inigo Montoya. You killed my father. Prepare to die."
  println sentence
  
  //NOTE: the method signature change
  println sentence.abbreviate(15)


  // println sentence.capitaliseAllWords()
  // println sentence.shout()
  // println sentence.countLetters()
  // println sentence.abbreviate(10).capitaliseAllWords()
  // println sentence.size()
}

//NOTE: this will fail since it is outside of the Category
// println "Test".shout()




class TestCategoryForString{
  static String shout(String input){
    return input.toUpperCase()
  }
  
  static int countLetters(String input){
    return 100
  }
  
  static int size(String input){
    return 7
  }
  
  
}








