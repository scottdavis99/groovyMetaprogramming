def hi = { name, city->
  println "Hello $name from $city"
}


//println hi.getClass()

hi("Scott", 12)

