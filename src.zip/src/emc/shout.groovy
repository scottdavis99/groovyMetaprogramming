def message = "I love groovy"

String.metaClass.shout = {
  return delegate.toUpperCase()
}
println message.shout()

//NOTE: this will fail if you change String.metaClass to message.metaClass
//      with the following exception:
// Caught: groovy.lang.MissingMethodException: No signature of method: 
// java.lang.String.shout() is applicable for argument types: () values: []
//
// The reason for the error is class-level metaprogramming 
// vs. instance-level metaprogramming

//println "Goodbye".shout()

