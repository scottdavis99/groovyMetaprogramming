//println "ls -al".execute().text

println "http://search.twitter.com/search.atom?q=gids".toURL().text